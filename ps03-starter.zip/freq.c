/* Getting the frequency of leading digits */

#include <stdio.h>

int getMSDigit(int x) {
   /* TODO: extract the leading digit of integer x and return it */
}

int main() {
   /* TODO: 
    * Read input from the stdin till EOF
    * For each integer, obtain the leading digit
    * Calculate the frequencies of the leading digits
    * Print the frequencies on stdout */
    return 0;
}
