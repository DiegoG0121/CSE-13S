/* Implementing a basic arithmetic calculator */

#include <stdio.h>

int main() {
    int choice, num1, num2;
    float result;

    /* TODO: display the menu of options and take user input, perform the chosen operation and display result.
             your program should continue until the user chooses to exit. 
             format your print statements exactly as the ones shown in sample output in the pdf */

  
    return 0;
}
