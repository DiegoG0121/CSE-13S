5. Explain your answers (18 points)

Please answer the following questions for each file you wrote as part of this assignment.

1. Making change
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.

The main point behind this program is recursion, recursion is a function that act's simmilarily to a loop, 
while chaning it paramters. It counts all the possible combinations of coins to make the change using the 
vlues 1, 2, 4, and 8; splitting the problem into two different cases, were the current coin is included and
not included, while adding them up. This way works because it looks for all the various option systematically.


2. Frequency of leading digits
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.

The program works by pulling out the most significant digit through each number & and counting how often each
digit appears. Then, dividing all the numbers by 10, to remove all digits and one digit remains giving use the
leading digit. Storing it within an array and printing the correct tallies of how many times each digit occurs.

3. Multiplying matrices
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.

The first part of the program has to verifies that the number of  columns within the matrix are equal to the number
of rows in Matrix B, which determines if they are compatible for multiplication. For each entry, of array [x][y] it
computes the dot product of row x of A and column y of B.  Using nested loops systematically computes every element
of the results without any duplications; then printing using nested for loops.

4. Merge sort
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.

Merge sort has a unique way of sorting, it divides the array into two different halves untik each subarray has a element,
which is trivially sorted. It takes two sorted subarrays and repeatedly slects the smaller front element in order to build
a singular sorted array, preserving order without missing or duplicating the elements in the array.

